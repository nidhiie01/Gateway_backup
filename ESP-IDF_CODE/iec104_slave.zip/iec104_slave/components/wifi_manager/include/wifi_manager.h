#pragma once

/**
 * @file  wifi_manager.h
 * @brief WiFi Station Manager — public API
 *
 * Wraps the ESP-IDF WiFi + event-loop APIs.
 * Used by iec104_slave.cpp to establish network connectivity.
 *
 * Platform: ESP32 / ESP-IDF v5.4.1
 */

#include "esp_err.h"
#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief  Initialise WiFi in Station mode and connect.
 *         Blocks until IP is obtained via DHCP or max retries exceeded.
 *         Prints the assigned IP address to the log.
 *
 * @param  ssid        WiFi network name
 * @param  password    WiFi password
 * @param  timeout_ms  Maximum wait time in milliseconds
 * @return ESP_OK on success, ESP_FAIL on connection failure
 */
esp_err_t wifi_manager_connect(const char* ssid,
                                const char* password,
                                uint32_t    timeout_ms);

/**
 * @brief  Disconnect from WiFi and deinitialise the driver.
 */
void wifi_manager_disconnect(void);

/**
 * @brief  Return true if WiFi is connected and has an IP address.
 */
bool wifi_manager_is_connected(void);

#ifdef __cplusplus
}
#endif
