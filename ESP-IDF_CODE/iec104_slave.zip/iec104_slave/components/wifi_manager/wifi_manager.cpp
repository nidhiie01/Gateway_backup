/**
 * @file  wifi_manager.cpp
 * @brief WiFi Station Manager implementation
 *
 * Platform: ESP32 / ESP-IDF v5.4.1
 */

#include "wifi_manager.h"

#include "freertos/FreeRTOS.h"
#include "freertos/event_groups.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_netif.h"
#include "esp_log.h"

#include <cstring>

static const char* TAG = "WiFiManager";

/* ── EventGroup bit flags ─────────────────────────────────────────────────── */
static constexpr EventBits_t BIT_CONNECTED = BIT0;
static constexpr EventBits_t BIT_FAILED    = BIT1;

/* ── Module-level state (single WiFi instance) ───────────────────────────── */
static EventGroupHandle_t  s_eventGroup  = nullptr;
static bool                s_connected   = false;
static uint8_t             s_retryCount  = 0u;
static constexpr uint8_t   MAX_RETRIES   = 5u;

/* ── Forward declarations of event handlers ──────────────────────────────── */
static void on_wifi_event(void* arg, esp_event_base_t base,
                          int32_t event_id, void* event_data);
static void on_ip_event  (void* arg, esp_event_base_t base,
                          int32_t event_id, void* event_data);

/* =========================================================================
 * wifi_manager_connect
 * ========================================================================= */
esp_err_t wifi_manager_connect(const char* ssid,
                                const char* password,
                                uint32_t    timeout_ms)
{
    /* Create synchronisation event group */
    s_eventGroup = xEventGroupCreate();
    if (s_eventGroup == nullptr) {
        ESP_LOGE(TAG, "Failed to create EventGroup");
        return ESP_FAIL;
    }

    /* Initialise TCP/IP network interface */
    ESP_ERROR_CHECK(esp_netif_init());

    /* Create the default event loop (safe to call even if already created) */
    esp_err_t loop_err = esp_event_loop_create_default();
    if (loop_err != ESP_OK && loop_err != ESP_ERR_INVALID_STATE) {
        ESP_ERROR_CHECK(loop_err);
    }

    /* Create the default WiFi STA network interface */
    esp_netif_create_default_wifi_sta();

    /* Initialise the WiFi driver with default config */
    wifi_init_config_t init_cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&init_cfg));

    /* Register event handlers */
    ESP_ERROR_CHECK(esp_event_handler_instance_register(
        WIFI_EVENT, ESP_EVENT_ANY_ID, on_wifi_event, nullptr, nullptr));
    ESP_ERROR_CHECK(esp_event_handler_instance_register(
        IP_EVENT, IP_EVENT_STA_GOT_IP, on_ip_event, nullptr, nullptr));

    /* Configure station mode with credentials */
    wifi_config_t wifi_cfg = {};
    strncpy(reinterpret_cast<char*>(wifi_cfg.sta.ssid),
            ssid, sizeof(wifi_cfg.sta.ssid) - 1u);
    strncpy(reinterpret_cast<char*>(wifi_cfg.sta.password),
            password, sizeof(wifi_cfg.sta.password) - 1u);
    wifi_cfg.sta.threshold.authmode = WIFI_AUTH_WPA2_PSK;
    wifi_cfg.sta.pmf_cfg.capable    = true;
    wifi_cfg.sta.pmf_cfg.required   = false;

    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA, &wifi_cfg));
    ESP_ERROR_CHECK(esp_wifi_start());

    ESP_LOGI(TAG, "Connecting to SSID: %s ...", ssid);

    /* Block until connected or failed */
    const TickType_t ticks = pdMS_TO_TICKS(timeout_ms);
    const EventBits_t bits = xEventGroupWaitBits(
        s_eventGroup,
        BIT_CONNECTED | BIT_FAILED,
        pdFALSE, pdFALSE,
        ticks);

    if (bits & BIT_CONNECTED) {
        return ESP_OK;
    }

    ESP_LOGE(TAG, "WiFi connection failed or timed out");
    return ESP_FAIL;
}

/* =========================================================================
 * wifi_manager_disconnect
 * ========================================================================= */
void wifi_manager_disconnect(void)
{
    esp_wifi_disconnect();
    esp_wifi_stop();
    esp_wifi_deinit();
    s_connected = false;
}

/* =========================================================================
 * wifi_manager_is_connected
 * ========================================================================= */
bool wifi_manager_is_connected(void)
{
    return s_connected;
}

/* =========================================================================
 * WiFi event handler
 * ========================================================================= */
static void on_wifi_event(void* /*arg*/, esp_event_base_t /*base*/,
                          int32_t event_id, void* /*data*/)
{
    switch (event_id) {

        case WIFI_EVENT_STA_START:
            esp_wifi_connect();
            break;

        case WIFI_EVENT_STA_CONNECTED:
            s_retryCount = 0u;
            ESP_LOGD(TAG, "Associated — waiting for IP ...");
            break;

        case WIFI_EVENT_STA_DISCONNECTED:
            s_connected = false;
            if (s_retryCount < MAX_RETRIES) {
                ++s_retryCount;
                ESP_LOGW(TAG, "Disconnected — retry %u/%u", s_retryCount, MAX_RETRIES);
                vTaskDelay(pdMS_TO_TICKS(2000u));
                esp_wifi_connect();
            } else {
                ESP_LOGE(TAG, "Max retries reached");
                xEventGroupSetBits(s_eventGroup, BIT_FAILED);
            }
            break;

        default:
            break;
    }
}

/* =========================================================================
 * IP event handler
 * ========================================================================= */
static void on_ip_event(void* /*arg*/, esp_event_base_t /*base*/,
                        int32_t event_id, void* event_data)
{
    if (event_id == IP_EVENT_STA_GOT_IP) {
        const auto* evt = static_cast<ip_event_got_ip_t*>(event_data);
        s_connected     = true;
        s_retryCount    = 0u;

        /* ─────────────────────────────────────────────────────────────────
         * Print the IP address prominently.
         * The user MUST enter this IP in The Vinci's IP field.
         * ───────────────────────────────────────────────────────────────── */
        ESP_LOGI(TAG, "╔═════════════════════════════════════════╗");
        ESP_LOGI(TAG, "║  WiFi Connected!                        ║");
        ESP_LOGI(TAG, "║  ESP32 IP: " IPSTR "                 ║",
                 IP2STR(&evt->ip_info.ip));
        ESP_LOGI(TAG, "║  Enter this IP in The Vinci Master tool ║");
        ESP_LOGI(TAG, "╚═════════════════════════════════════════╝");

        xEventGroupSetBits(s_eventGroup, BIT_CONNECTED);
        xEventGroupClearBits(s_eventGroup, BIT_FAILED);
    }
}
