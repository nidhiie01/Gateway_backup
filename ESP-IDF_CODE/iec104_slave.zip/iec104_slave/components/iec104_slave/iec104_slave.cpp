/**
 * @file    iec104_slave.cpp
 * @brief   IEC 60870-5-104 Slave (Controlled Station / TCP Server)
 *          Implementation — Phase 1: STARTDT handshake
 *
 * All protocol values are taken from IEC 60870-5-104 Edition 2.0 (2006).
 * No existing IEC 104 library code is copied or derived here.
 *
 * Platform : ESP32 / ESP-IDF v5.4.1 / FreeRTOS / lwIP
 */

#include "iec104_slave.h"
#include "wifi_manager.h"

/* lwIP POSIX socket API (ESP-IDF exposes this for ESP32) */
#include "lwip/sockets.h"
#include "lwip/netdb.h"

#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include <cstring>
#include <cerrno>

static const char* TAG = "IEC104Slave";

/* =========================================================================
 * Module-level socket file descriptors
 *
 * Two separate descriptors are needed for a TCP server:
 *  s_listen_fd : the server socket — used only for bind/listen/accept
 *  s_conn_fd   : the connection socket — used for send/recv with the master
 *
 * They are kept at module scope so iec104_server_stop() can close both
 * without passing them as parameters.
 * ========================================================================= */
static int s_listen_fd = -1;   /* Listening server socket */
static int s_conn_fd   = -1;   /* Active connection socket (from accept) */

/* =========================================================================
 * Internal helper: send exactly len bytes, retrying if needed
 * ========================================================================= */
static bool send_all(int fd, const uint8_t* buf, size_t len)
{
    size_t sent = 0u;
    while (sent < len) {
        const int n = send(fd,
                           reinterpret_cast<const char*>(buf + sent),
                           static_cast<int>(len - sent),
                           0);
        if (n <= 0) {
            ESP_LOGW(TAG, "send() returned %d (errno=%d)", n, errno);
            return false;
        }
        sent += static_cast<size_t>(n);
    }
    return true;
}

/* =========================================================================
 * Internal helper: receive exactly len bytes, retrying if needed
 * Returns true when all bytes received, false on error/timeout/disconnect.
 * ========================================================================= */
static bool recv_all(int fd, uint8_t* buf, size_t len)
{
    size_t got = 0u;
    while (got < len) {
        const int n = recv(fd,
                           reinterpret_cast<char*>(buf + got),
                           static_cast<int>(len - got),
                           0);
        if (n < 0) {
            if (errno == EAGAIN || errno == EWOULDBLOCK) {
                /* SO_RCVTIMEO expired — master did not send in time */
                ESP_LOGW(TAG, "recv() timed out waiting for data");
                return false;
            }
            ESP_LOGW(TAG, "recv() error: errno=%d", errno);
            return false;
        }
        if (n == 0) {
            /* Master closed the connection (TCP FIN received) */
            ESP_LOGW(TAG, "Master closed the connection (received EOF)");
            return false;
        }
        got += static_cast<size_t>(n);
    }
    return true;
}

/* =========================================================================
 * iec104_wifi_init
 *
 * Delegates to the wifi_manager component.
 * Uses WIFI_SSID and WIFI_PASSWORD defined in iec104_slave.h.
 * ========================================================================= */
iec104_err_t iec104_wifi_init(void)
{
    ESP_LOGI(TAG, "Connecting to WiFi SSID: %s", WIFI_SSID);

    const esp_err_t err = wifi_manager_connect(WIFI_SSID,
                                                WIFI_PASSWORD,
                                                WIFI_TIMEOUT_MS);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "WiFi connection failed");
        return IEC104_ERR_WIFI;
    }

    return IEC104_OK;
}

/* =========================================================================
 * iec104_server_start
 *
 * Creates a TCP server socket, binds to port 2404, and starts listening.
 *
 * Key decisions:
 *  - SO_REUSEADDR: allows the ESP32 to restart and rebind immediately
 *    without waiting for the TIME_WAIT state to expire (common issue).
 *  - INADDR_ANY: accepts connections on any available network interface.
 *  - Backlog = 1: only one master connection needed for Phase 1.
 * ========================================================================= */
iec104_err_t iec104_server_start(void)
{
    /* ── Create TCP socket ────────────────────────────────────────────────── */
    s_listen_fd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (s_listen_fd < 0) {
        ESP_LOGE(TAG, "socket() failed: errno=%d", errno);
        return IEC104_ERR_SOCKET;
    }
    ESP_LOGD(TAG, "Server socket created (fd=%d)", s_listen_fd);

    /* ── Allow address reuse ─────────────────────────────────────────────── */
    const int reuse = 1;
    if (setsockopt(s_listen_fd, SOL_SOCKET, SO_REUSEADDR,
                   &reuse, sizeof(reuse)) < 0) {
        /* Non-fatal — log and continue */
        ESP_LOGW(TAG, "SO_REUSEADDR failed (errno=%d) — continuing anyway", errno);
    }

    /* ── Bind to port 2404 on all interfaces ─────────────────────────────── */
    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family      = AF_INET;
    addr.sin_port        = htons(static_cast<uint16_t>(IEC104_SLAVE_PORT));
    addr.sin_addr.s_addr = htonl(INADDR_ANY);   /* Accept on any interface */

    if (bind(s_listen_fd,
             reinterpret_cast<const struct sockaddr*>(&addr),
             sizeof(addr)) < 0) {
        ESP_LOGE(TAG, "bind() failed on port %u: errno=%d",
                 IEC104_SLAVE_PORT, errno);
        close(s_listen_fd);
        s_listen_fd = -1;
        return IEC104_ERR_SOCKET;
    }
    ESP_LOGD(TAG, "Socket bound to port %u", IEC104_SLAVE_PORT);

    /* ── Start listening ──────────────────────────────────────────────────── */
    if (listen(s_listen_fd, 1) < 0) {
        ESP_LOGE(TAG, "listen() failed: errno=%d", errno);
        close(s_listen_fd);
        s_listen_fd = -1;
        return IEC104_ERR_SOCKET;
    }

    ESP_LOGI(TAG, "TCP server listening on port %u", IEC104_SLAVE_PORT);
    return IEC104_OK;
}

/* =========================================================================
 * iec104_server_accept
 *
 * Blocks until the IEC 104 Master (The Vinci) connects.
 * accept() is a blocking call — it returns only when a client connects.
 * ========================================================================= */
iec104_err_t iec104_server_accept(void)
{
    if (s_listen_fd < 0) {
        ESP_LOGE(TAG, "accept() called but server socket is not open");
        return IEC104_ERR_SOCKET;
    }

    /* master_addr will be filled with The Vinci's IP and port */
    struct sockaddr_in master_addr;
    socklen_t          addr_len = sizeof(master_addr);

    ESP_LOGI(TAG, "Waiting for Master to connect (blocking) ...");

    s_conn_fd = accept(s_listen_fd,
                       reinterpret_cast<struct sockaddr*>(&master_addr),
                       &addr_len);
    if (s_conn_fd < 0) {
        ESP_LOGE(TAG, "accept() failed: errno=%d", errno);
        return IEC104_ERR_ACCEPT;
    }

    /* ── Log the master's IP and port ────────────────────────────────────── */
    char master_ip[INET_ADDRSTRLEN] = {};
    inet_ntop(AF_INET, &master_addr.sin_addr, master_ip, sizeof(master_ip));
    ESP_LOGI(TAG, "Master connected from %s:%u (fd=%d)",
             master_ip,
             ntohs(master_addr.sin_port),
             s_conn_fd);

    /* ── Set receive timeout on the connection socket ────────────────────── */
    const uint32_t timeout_sec  = IEC104_STARTDT_TIMEOUT_MS / 1000u;
    const uint32_t timeout_usec = (IEC104_STARTDT_TIMEOUT_MS % 1000u) * 1000u;
    struct timeval rcv_timeout;
    rcv_timeout.tv_sec  = static_cast<long>(timeout_sec);
    rcv_timeout.tv_usec = static_cast<long>(timeout_usec);
    setsockopt(s_conn_fd, SOL_SOCKET, SO_RCVTIMEO,
               &rcv_timeout, sizeof(rcv_timeout));

    /* ── Disable Nagle algorithm for low-latency response ────────────────── */
    const int no_delay = 1;
    setsockopt(s_conn_fd, IPPROTO_TCP, TCP_NODELAY,
               &no_delay, sizeof(no_delay));

    return IEC104_OK;
}

/* =========================================================================
 * iec104_slave_startdt_handshake
 *
 * Phase 1 core function.
 *
 * The Vinci (Master/TCP Client) will send STARTDT_act immediately after
 * the TCP connection is established. This function:
 *
 *   1. Reads 6 bytes from the master.
 *   2. Validates the frame:
 *        - Byte 0 must be 0x68 (start byte, IEC 60870-5-104 §5.1)
 *        - Byte 1 must be 0x04 (U-frame length, no ASDU payload)
 *        - Byte 2 must be 0x07 (CF1 for STARTDT_act, Table 4)
 *   3. Builds the STARTDT_con response:
 *        0x68  0x04  0x0B  0x00  0x00  0x00
 *   4. Sends STARTDT_con to the master.
 *   5. Logs success.
 * ========================================================================= */
iec104_err_t iec104_slave_startdt_handshake(void)
{
    if (s_conn_fd < 0) {
        ESP_LOGE(TAG, "startdt_handshake() called with no active connection");
        return IEC104_ERR_SOCKET;
    }

    /* ── Step 1: Receive exactly 6 bytes (one U-frame) from the master ───── */
    uint8_t rx[IEC104_UFRAME_SIZE] = {};

    ESP_LOGI(TAG, "Waiting to receive STARTDT_act from Master ...");

    if (!recv_all(s_conn_fd, rx, IEC104_UFRAME_SIZE)) {
        ESP_LOGE(TAG, "Failed to receive STARTDT_act frame");
        return IEC104_ERR_RECV;
    }

    /* Log the raw bytes received */
    ESP_LOGI(TAG, "RX (%zu bytes): %02X %02X %02X %02X %02X %02X",
             (size_t)IEC104_UFRAME_SIZE,
             rx[0], rx[1], rx[2], rx[3], rx[4], rx[5]);

    /* ── Step 2: Validate frame ──────────────────────────────────────────── */

    /* Check start byte (must always be 0x68) */
    if (rx[0] != IEC104_START_BYTE) {
        ESP_LOGE(TAG, "Frame validation FAILED: byte[0]=0x%02X, expected 0x68",
                 rx[0]);
        ESP_LOGE(TAG, "  → This is not an IEC 104 frame");
        return IEC104_ERR_BAD_FRAME;
    }

    /* Check length byte (must be 0x04 for a U-frame with no ASDU) */
    if (rx[1] != IEC104_UFRAME_LENGTH) {
        ESP_LOGE(TAG, "Frame validation FAILED: byte[1]=0x%02X, expected 0x04",
                 rx[1]);
        ESP_LOGE(TAG, "  → Unexpected frame length");
        return IEC104_ERR_BAD_FRAME;
    }

    /* Check that this is a U-frame: bits [1:0] of CF1 must both be 1 */
    if ((rx[2] & IEC104_UFRAME_MASK) != IEC104_UFRAME_PATTERN) {
        ESP_LOGE(TAG, "Frame validation FAILED: byte[2]=0x%02X is not a U-frame",
                 rx[2]);
        ESP_LOGE(TAG, "  → Expected a U-frame (bits[1:0] of CF1 must be 0b11)");
        return IEC104_ERR_BAD_FRAME;
    }

    /* Check that CF1 specifically is STARTDT_act (0x07) */
    if (rx[2] != IEC104_CF1_STARTDT_ACT) {
        ESP_LOGW(TAG, "Received a valid U-frame but CF1=0x%02X is not STARTDT_act(0x07)",
                 rx[2]);
        /* Log what we actually received for debugging */
        const char* name = "UNKNOWN";
        if (rx[2] == IEC104_CF1_STOPDT_ACT) name = "STOPDT_act";
        if (rx[2] == IEC104_CF1_TESTFR_ACT) name = "TESTFR_act";
        if (rx[2] == IEC104_CF1_TESTFR_CON) name = "TESTFR_con";
        ESP_LOGW(TAG, "  → Received: %s (0x%02X)", name, rx[2]);
        return IEC104_ERR_WRONG_CMD;
    }

    /* All validation passed */
    ESP_LOGI(TAG, "RX  STARTDT_act  [%02X %02X %02X %02X %02X %02X]  ✓ valid",
             rx[0], rx[1], rx[2], rx[3], rx[4], rx[5]);

    /* ── Step 3: Build STARTDT_con response ──────────────────────────────── */
    /*
     * STARTDT_con wire format (IEC 60870-5-104, Table 4):
     *   Byte 0: 0x68 — start byte (always)
     *   Byte 1: 0x04 — length = 4 (U-frame, no ASDU)
     *   Byte 2: 0x0B — CF1 = STARTDT_con
     *   Byte 3: 0x00 — CF2 (not used in U-frames)
     *   Byte 4: 0x00 — CF3 (not used in U-frames)
     *   Byte 5: 0x00 — CF4 (not used in U-frames)
     */
    const iec104_uframe_t startdt_con = {
        .start  = IEC104_START_BYTE,
        .length = IEC104_UFRAME_LENGTH,
        .cf1    = IEC104_CF1_STARTDT_CON,
        .cf2    = 0x00U,
        .cf3    = 0x00U,
        .cf4    = 0x00U
    };

    /* ── Step 4: Send STARTDT_con to the master ──────────────────────────── */
    const uint8_t* tx = reinterpret_cast<const uint8_t*>(&startdt_con);

    if (!send_all(s_conn_fd, tx, IEC104_UFRAME_SIZE)) {
        ESP_LOGE(TAG, "Failed to send STARTDT_con");
        return IEC104_ERR_SEND;
    }

    ESP_LOGI(TAG, "TX  STARTDT_con  [%02X %02X %02X %02X %02X %02X]  ✓ sent",
             tx[0], tx[1], tx[2], tx[3], tx[4], tx[5]);

    /* ── Step 5: Confirm success ─────────────────────────────────────────── */
    ESP_LOGI(TAG, "════════════════════════════════════════════");
    ESP_LOGI(TAG, "  IEC104: Slave Connected                   ");
    ESP_LOGI(TAG, "  Data transfer link is now ACTIVE          ");
    ESP_LOGI(TAG, "════════════════════════════════════════════");

    return IEC104_OK;
}

/* =========================================================================
 * iec104_server_stop
 *
 * Closes both sockets cleanly.
 * shutdown(SHUT_RDWR) unblocks any pending recv()/accept() calls first,
 * then close() releases the file descriptor.
 * ========================================================================= */
void iec104_server_stop(void)
{
    if (s_conn_fd >= 0) {
        shutdown(s_conn_fd, SHUT_RDWR);
        close(s_conn_fd);
        s_conn_fd = -1;
        ESP_LOGD(TAG, "Connection socket closed");
    }

    if (s_listen_fd >= 0) {
        shutdown(s_listen_fd, SHUT_RDWR);
        close(s_listen_fd);
        s_listen_fd = -1;
        ESP_LOGD(TAG, "Listen socket closed");
    }
}
