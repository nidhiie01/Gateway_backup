/**
 * @file    iec104_slave.h
 * @brief   IEC 60870-5-104  Slave (Controlled Station) — Public API
 *
 * ─────────────────────────────────────────────────────────────────────────────
 * ARCHITECTURE OVERVIEW
 * ─────────────────────────────────────────────────────────────────────────────
 *
 *   The Vinci (PC)                          ESP32 Gateway
 *   ─────────────────                       ─────────────────────────────────
 *   IEC 104 Master                          IEC 104 Slave
 *   = Controlling Station                   = Controlled Station
 *   = TCP CLIENT  ────── connects to ──────▶ = TCP SERVER (listens port 2404)
 *
 *   The Vinci INITIATES the TCP connection TO the ESP32.
 *   The ESP32 LISTENS and ACCEPTS the connection FROM The Vinci.
 *
 * ─────────────────────────────────────────────────────────────────────────────
 * PHASE 1 SEQUENCE (this file)
 * ─────────────────────────────────────────────────────────────────────────────
 *
 *   The Vinci (TCP Client)         ESP32 Slave (TCP Server)
 *   ────────────────────           ────────────────────────
 *                                  bind(port 2404)
 *                                  listen()
 *   connect() ──────────────────▶  accept()
 *   STARTDT_act ────────────────▶  recv() — validate start byte + CF1
 *                 ◀──────────────  send() — STARTDT_con
 *                                  log "IEC104: Slave Connected"
 *
 * ─────────────────────────────────────────────────────────────────────────────
 * PROTOCOL CONSTANTS — Source: IEC 60870-5-104 Edition 2.0 (2006)
 * ─────────────────────────────────────────────────────────────────────────────
 *
 *  Every APDU starts with: 0x68 (= 104 decimal → the protocol's nickname)
 *
 *  U-frame wire layout (6 bytes total):
 *  ┌────────┬────────┬─────┬─────┬─────┬─────┐
 *  │  0x68  │  0x04  │ CF1 │ CF2 │ CF3 │ CF4 │
 *  │  Start │ Length │     │0x00 │0x00 │0x00 │
 *  └────────┴────────┴─────┴─────┴─────┴─────┘
 *
 *  CF1 values (Table 4, IEC 60870-5-104):
 *    STARTDT_act = 0x07   STARTDT_con = 0x0B
 *    STOPDT_act  = 0x13   STOPDT_con  = 0x23
 *    TESTFR_act  = 0x43   TESTFR_con  = 0x83
 *
 * Author  : Original implementation — IEC 60870-5-104 Ed.2 specification
 * Target  : ESP32 / ESP-IDF v5.4.1 / FreeRTOS
 */

#ifndef IEC104_SLAVE_H
#define IEC104_SLAVE_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include <stddef.h>

/* =========================================================================
 * USER CONFIGURATION — EDIT THESE BEFORE BUILDING
 * ========================================================================= */

/** WiFi SSID (network name). Replace with your actual SSID. */
#define WIFI_SSID           "Adiinfigtpl4G"

/** WiFi password. Replace with your actual password. */
#define WIFI_PASSWORD       "Adiinfi@1234"

/** Maximum milliseconds to wait for WiFi + DHCP to complete. */
#define WIFI_TIMEOUT_MS     15000u

/* =========================================================================
 * IEC 60870-5-104 PROTOCOL CONSTANTS
 * Values taken directly from IEC 60870-5-104 Edition 2.0, Section 5.
 * Do NOT change these — they are defined by the standard.
 * ========================================================================= */

/**
 * @brief First byte of every IEC 104 APDU.
 *        Fixed value 0x68 (= decimal 104, hence the protocol nickname).
 *        Defined in IEC 60870-5-104, Section 5.1.
 */
#define IEC104_START_BYTE       0x68U

/**
 * @brief Value of the Length field in a U-frame.
 *        U-frames have no ASDU payload, so only 4 control bytes follow:
 *        Length = 4  (CF1 + CF2 + CF3 + CF4).
 */
#define IEC104_UFRAME_LENGTH    0x04U

/**
 * @brief Total wire size of a U-frame APDU in bytes.
 *        = Start(1) + Length(1) + CF1(1) + CF2(1) + CF3(1) + CF4(1) = 6
 */
#define IEC104_UFRAME_SIZE      6U

/**
 * @brief TCP port for IEC 60870-5-104 (IANA registered).
 *        The slave listens on this port. The master connects to this port.
 */
#define IEC104_SLAVE_PORT       2404U

/**
 * @brief Maximum milliseconds to wait for STARTDT_act from the master
 *        after the TCP connection is accepted.
 */
#define IEC104_STARTDT_TIMEOUT_MS   10000u

/* ─────────────────────────────────────────────────────────────────────────
 * U-Frame Control Field 1 (CF1) byte values
 * Source: IEC 60870-5-104, Table 4 — U-format control field encodings
 * ───────────────────────────────────────────────────────────────────────── */

/** CF1 = 0x07 — STARTDT activate: sent by Master to begin data transfer */
#define IEC104_CF1_STARTDT_ACT  0x07U

/** CF1 = 0x0B — STARTDT confirm: sent by Slave to acknowledge data transfer */
#define IEC104_CF1_STARTDT_CON  0x0BU

/** CF1 = 0x13 — STOPDT activate: sent by Master to pause data transfer */
#define IEC104_CF1_STOPDT_ACT   0x13U

/** CF1 = 0x23 — STOPDT confirm: sent by Slave */
#define IEC104_CF1_STOPDT_CON   0x23U

/** CF1 = 0x43 — TESTFR activate: keep-alive probe */
#define IEC104_CF1_TESTFR_ACT   0x43U

/** CF1 = 0x83 — TESTFR confirm: keep-alive response */
#define IEC104_CF1_TESTFR_CON   0x83U

/* ─────────────────────────────────────────────────────────────────────────
 * Frame type detection masks (Section 5.1, IEC 60870-5-104)
 *   I-frame: bit 0 of CF1 == 0          → mask 0x01, value 0x00
 *   S-frame: bits [1:0] of CF1 == 0b01  → mask 0x03, value 0x01
 *   U-frame: bits [1:0] of CF1 == 0b11  → mask 0x03, value 0x03
 * ───────────────────────────────────────────────────────────────────────── */

#define IEC104_UFRAME_MASK      0x03U   /**< Bits used to identify U-frame */
#define IEC104_UFRAME_PATTERN   0x03U   /**< Both bits [1:0] must be 1     */

/* =========================================================================
 * DATA TYPES
 * ========================================================================= */

/**
 * @brief In-memory representation of a U-frame APDU (matches wire layout).
 *
 *  Wire order (6 bytes):
 *  offset 0: start   — always IEC104_START_BYTE (0x68)
 *  offset 1: length  — always IEC104_UFRAME_LENGTH (0x04) for U-frames
 *  offset 2: cf1     — encodes the U-frame command (STARTDT/STOPDT/TESTFR)
 *  offset 3: cf2     — 0x00 for all U-frames
 *  offset 4: cf3     — 0x00 for all U-frames
 *  offset 5: cf4     — 0x00 for all U-frames
 */
typedef struct {
    uint8_t start;      /**< IEC104_START_BYTE = 0x68          */
    uint8_t length;     /**< IEC104_UFRAME_LENGTH = 0x04       */
    uint8_t cf1;        /**< Command: STARTDT/STOPDT/TESTFR    */
    uint8_t cf2;        /**< Always 0x00 for U-frames          */
    uint8_t cf3;        /**< Always 0x00 for U-frames          */
    uint8_t cf4;        /**< Always 0x00 for U-frames          */
} iec104_uframe_t;

/**
 * @brief Return codes for all IEC 104 slave API functions.
 */
typedef enum {
    IEC104_OK               =  0,   /**< Operation succeeded                 */
    IEC104_ERR_WIFI         = -1,   /**< WiFi connection failed              */
    IEC104_ERR_SOCKET       = -2,   /**< socket() / bind() / listen() failed */
    IEC104_ERR_ACCEPT       = -3,   /**< accept() failed                     */
    IEC104_ERR_RECV         = -4,   /**< recv() failed or timed out          */
    IEC104_ERR_SEND         = -5,   /**< send() failed                       */
    IEC104_ERR_BAD_FRAME    = -6,   /**< Received frame failed validation    */
    IEC104_ERR_WRONG_CMD    = -7,   /**< Expected STARTDT_act, got something else */
} iec104_err_t;

/* =========================================================================
 * PUBLIC API FUNCTIONS
 * ========================================================================= */

/**
 * @brief  Initialise and connect ESP32 to WiFi (Station mode).
 *
 *         Uses WIFI_SSID and WIFI_PASSWORD defined above.
 *         Blocks until an IP address is obtained via DHCP, or until
 *         WIFI_TIMEOUT_MS milliseconds have elapsed.
 *
 *         IMPORTANT: The assigned IP address is printed to the log.
 *         Write it down — you must enter it in The Vinci's IP field.
 *
 * @return IEC104_OK on success, IEC104_ERR_WIFI on failure.
 */
iec104_err_t iec104_wifi_init(void);

/**
 * @brief  Create a TCP server socket and start listening on port 2404.
 *
 *         Steps performed:
 *           1. socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)
 *           2. setsockopt SO_REUSEADDR (allows quick restart)
 *           3. bind() to INADDR_ANY : IEC104_SLAVE_PORT
 *           4. listen() with backlog = 1
 *
 *         After this call, the socket is ready but no master has
 *         connected yet. Call iec104_server_accept() next.
 *
 * @return IEC104_OK on success, IEC104_ERR_SOCKET on failure.
 */
iec104_err_t iec104_server_start(void);

/**
 * @brief  Block until the IEC 104 Master (The Vinci) establishes a TCP
 *         connection to this slave.
 *
 *         Calls accept() on the listening socket created by
 *         iec104_server_start(). Blocks indefinitely until a client connects
 *         (The Vinci will connect when you click Start in Master mode).
 *
 *         On success, the connection socket is stored internally and used
 *         by subsequent send/receive calls.
 *
 * @return IEC104_OK on success, IEC104_ERR_ACCEPT on failure.
 */
iec104_err_t iec104_server_accept(void);

/**
 * @brief  Perform the STARTDT handshake as the Slave (server side).
 *
 *         Steps performed:
 *           1. Receive 6 bytes from the master
 *           2. Validate: start byte must be 0x68, length must be 0x04,
 *              CF1 must be IEC104_CF1_STARTDT_ACT (0x07)
 *           3. Build and send STARTDT_con (6 bytes: 0x68 0x04 0x0B 0x00 0x00 0x00)
 *           4. Log "IEC104: Slave Connected"
 *
 *         This is the Phase 1 goal. After this returns IEC104_OK, the
 *         IEC 104 data transfer link is active.
 *
 * @return IEC104_OK               — handshake complete, link is active
 * @return IEC104_ERR_RECV         — no data received within timeout
 * @return IEC104_ERR_BAD_FRAME    — start byte or length byte was wrong
 * @return IEC104_ERR_WRONG_CMD    — frame was valid but not STARTDT_act
 * @return IEC104_ERR_SEND         — could not send STARTDT_con
 */
iec104_err_t iec104_slave_startdt_handshake(void);

/**
 * @brief  Close all sockets and release resources.
 *         Safe to call multiple times.
 */
void iec104_server_stop(void);

#ifdef __cplusplus
}
#endif

#endif /* IEC104_SLAVE_H */
