/**
 * @file    main.cpp
 * @brief   Application Entry Point — IEC 60870-5-104 Slave (Phase 1)
 *
 * Architecture clarification:
 *
 *   ┌──────────────────────────┐          ┌──────────────────────────────┐
 *   │  The Vinci (PC)          │          │  ESP32 Gateway               │
 *   │  IEC 104 Master          │          │  IEC 104 Slave               │
 *   │  = Controlling Station   │          │  = Controlled Station        │
 *   │  = TCP CLIENT            │──TCP────▶│  = TCP SERVER (port 2404)    │
 *   │  connects TO the gateway │          │  listens, accepts connection  │
 *   └──────────────────────────┘          └──────────────────────────────┘
 *
 * Phase 1 goal:
 *   1. Connect ESP32 to WiFi — print the IP address (you need it for Vinci)
 *   2. Open a TCP server socket and listen on port 2404
 *   3. Accept the incoming TCP connection from The Vinci Master
 *   4. Receive STARTDT_act from The Vinci
 *   5. Send STARTDT_con back to The Vinci
 *   6. Print "IEC104: Slave Connected" on success
 *
 * Platform : ESP32 / ESP-IDF v5.4.1 / FreeRTOS
 * Network  : WiFi STA (same LAN as the PC running The Vinci)
 */

/* ── Includes ────────────────────────────────────────────────────────────── */
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include "nvs_flash.h"

#include "wifi_manager.h"
#include "iec104_slave.h"

/* ── Module log tag ─────────────────────────────────────────────────────── */
static const char* TAG = "APP_MAIN";

/* =========================================================================
 * app_main
 * ========================================================================= */
extern "C" void app_main(void)
{
    ESP_LOGI(TAG, "╔══════════════════════════════════════════════╗");
    ESP_LOGI(TAG, "║  IEC 60870-5-104  Slave Gateway  (Phase 1)  ║");
    ESP_LOGI(TAG, "║  Controlled Station  |  TCP Server           ║");
    ESP_LOGI(TAG, "║  ESP-IDF v5.4.1  /  FreeRTOS                ║");
    ESP_LOGI(TAG, "╚══════════════════════════════════════════════╝");

    /* ── Step 1: Initialise Non-Volatile Storage (required by WiFi) ───── */
    esp_err_t nvs_err = nvs_flash_init();
    if (nvs_err == ESP_ERR_NVS_NO_FREE_PAGES ||
        nvs_err == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_LOGW(TAG, "NVS partition corrupt — erasing");
        ESP_ERROR_CHECK(nvs_flash_erase());
        nvs_err = nvs_flash_init();
    }
    ESP_ERROR_CHECK(nvs_err);

    /* ── Step 2: Connect to WiFi ─────────────────────────────────────── */
    ESP_LOGI(TAG, "[Step 1] Starting WiFi ...");

    iec104_err_t result = iec104_wifi_init();
    if (result != IEC104_OK) {
        ESP_LOGE(TAG, "[Step 1] WiFi FAILED (code %d)", (int)result);
        ESP_LOGE(TAG, "  → Check WIFI_SSID and WIFI_PASSWORD in iec104_slave.h");
        goto halt;
    }

    /* WiFi connected. The IP address is printed inside iec104_wifi_init().
     * NOTE IT DOWN — you must enter it in The Vinci's IP field.            */
    ESP_LOGI(TAG, "[Step 1] WiFi OK — check IP address printed above");
    vTaskDelay(pdMS_TO_TICKS(300));

    /* ── Step 3: Start TCP Server on port 2404 ───────────────────────── */
    ESP_LOGI(TAG, "[Step 2] Starting IEC 104 TCP server on port %d ...",
             IEC104_SLAVE_PORT);

    result = iec104_server_start();
    if (result != IEC104_OK) {
        ESP_LOGE(TAG, "[Step 2] Server start FAILED (code %d)", (int)result);
        goto halt;
    }
    ESP_LOGI(TAG, "[Step 2] TCP server listening — waiting for Master (Vinci)");

    /* ── Step 4: Block until The Vinci Master connects ───────────────── */
    ESP_LOGI(TAG, "[Step 3] Waiting for incoming connection from The Vinci ...");
    ESP_LOGI(TAG, "         (Start The Vinci, set Mode=Master, IP=<this ESP32 IP>, Port=2404, click Start)");

    result = iec104_server_accept();
    if (result != IEC104_OK) {
        ESP_LOGE(TAG, "[Step 3] Accept FAILED (code %d)", (int)result);
        goto halt;
    }
    ESP_LOGI(TAG, "[Step 3] Master connected — TCP link established");

    /* ── Step 5: Receive STARTDT_act and send STARTDT_con ────────────── */
    ESP_LOGI(TAG, "[Step 4] Waiting for STARTDT_act from Master ...");

    result = iec104_slave_startdt_handshake();
    if (result != IEC104_OK) {
        ESP_LOGE(TAG, "[Step 4] STARTDT handshake FAILED (code %d)", (int)result);
        goto halt;
    }

    /* ── All steps passed ────────────────────────────────────────────── */
    ESP_LOGI(TAG, "╔══════════════════════════════════════════════╗");
    ESP_LOGI(TAG, "║  PHASE 1 COMPLETE — All steps passed  ✓     ║");
    ESP_LOGI(TAG, "║  IEC104: Slave Connected                     ║");
    ESP_LOGI(TAG, "╚══════════════════════════════════════════════╝");

    /* Keep the task alive — in Phase 2 we will exchange I-frames here */
    while (true) {
        vTaskDelay(pdMS_TO_TICKS(5000));
        ESP_LOGI(TAG, "Idle — Phase 1 test complete. Reset ESP32 to run again.");
    }

halt:
    iec104_server_stop();

    ESP_LOGE(TAG, "╔══════════════════════════════════════════════╗");
    ESP_LOGE(TAG, "║  HALTED — See error above. Reset to retry.  ║");
    ESP_LOGE(TAG, "╚══════════════════════════════════════════════╝");

    while (true) {
        vTaskDelay(pdMS_TO_TICKS(5000));
    }
}
